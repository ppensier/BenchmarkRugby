import ihm.authentification
ihm.authentification.Authentification(None)
